export class Header {
  appTitle = "Hahn";

  constructor() {
  }
}
